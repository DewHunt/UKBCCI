<?php
function getBusinessEmailBody ()
{
    return
        '<p> First Name: ' . $_POST['name'] . '</p></br>'
        . '<p> Sur Name: ' . $_POST['sur_name'] . '</p></br>'
        . '<p>Business Name: ' . $_POST['business_name'] . '</p></br>'
        . '<p>Business Address: ' . $_POST['business_address'] . '</p></br>'
        . '<p>Business Email Address: ' . $_POST['email'] . '</p></br>'
        . '<p>Business Contact Number: ' . $_POST['contact'] . '</p></br>';
}

?>