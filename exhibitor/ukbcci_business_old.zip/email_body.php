<?php

function getEmailBody ()
{
    return
        '<p> Dear  ' . $_POST["name"] . '</p></br>'
        . '<h3><u>Reference: UKBCCI Trade show and business networking event</u></h3>'
        . '<p>Thank you for kindly accepting our invitation to attend the UKBCCI trade show and business networking , to be held Monday 8th January 2024. </br> As we develop young entrepreneurs, our goal is to become a model for supporting both the current and future expansion of trade and industry in both nations.</br> The event is to bring together the business community from within the locality, to meet and network and to host a trade show for young British Bangladeshi entrepreneurs who have diversified into the many different sectors.</p>'

        . '<p> The event will be hosted at <b>Yasmin Banqueting, 1 Intown Row, Walsall, WS1 2AD </b>.</p>'
        . '<p>The programme is scheduled to start from 6.00pm followed by dinner. </p>'
        . '<p>As an exhibitor it would make your business standout at the show if you have pop up banners to put behind your table and business cards and leaflets to hand out to prospective clients. If you have any products also that would be good.The cost of one stall is £150.00 only. This is merely to cover costs.</p>'
        . '<p>Please provide payment using the link below:</p>'
        . '<p style="line-height:1px;">UKBCCI Ltd</p>'
        . '<p style="line-height:1px;">Barclays Bank</p>'
        . '<p style="line-height:1px;">Sort code: 20-41-50</p>'
        . '<p style="line-height:1px;">A/c no: 93909972</p>'
        . '<p style="line-height:1px;">Ref:' . $_POST["business_name"] . '</p> </br></br>'
        . '<p >We look forward to seeing you on the day.</p> </br>'
        . '<p>The non-profit UK Bangladesh Catalysts of Commerce and Industry (UKBCCI) works to support the UK business community and advance bilateral trade between the UK and Bangladesh.</p>'
        . '<p style="line-height:1px;"><b>With best wishes </b></p>'
        . '<p style="line-height:1px;">Imam Uddin Ahmad</p>'
        . '<p style="line-height:1px;">President</p>'
        . '<p style="line-height:1px;">Midlands Region</p>';
}

