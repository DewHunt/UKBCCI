<?php
function getBusinessEmailBody ()
{
    return
        '<p> Contact Name: ' . $_POST['name'] . '</p></br>'
        . '<p>Business Name And Address: ' . $_POST['business_name'] . '</p></br>'
        . '<p>Business Email Address: ' . $_POST['email'] . '</p></br>'
        . '<p>Business Contact Number: ' . $_POST['contact'] . '</p></br>';
}

?>